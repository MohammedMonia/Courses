<?php if(session()->has('alert.success')): ?>
<div class="alert alert-success">
  <?php echo e(session('alert.success')); ?>

</div>
<?php endif; ?>
<?php if(session()->has('alert.error')): ?>
<div class="alert alert-danger">
  <?php echo e(session('alert.error')); ?>

</div>
<?php endif; ?><?php /**PATH G:\PalLancer\Laravel\myblog\resources\views/fronts/_alert.blade.php ENDPATH**/ ?>