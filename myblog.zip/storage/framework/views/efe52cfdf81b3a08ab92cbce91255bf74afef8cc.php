

<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="main-wrapper">
	    	    
	    <article class="about-section py-5">
		    <div class="container">
            <figure><img class="img-fluid" src="<?php echo e($about->image); ?>" alt="image"></figure>
			    <h2 class="title mb-3"><?php echo e($about->about_title); ?></h2>
			    <p><?php echo $about->about_body; ?></p>
			    <h2 class="mt-5"><?php echo e($about->aboutBlog_title); ?></h2>
			    <p><?php echo $about->aboutBlog_body; ?></p>
            </div>
        </article>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fronts.appfront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PalLancer\Laravel\myblog\resources\views/fronts/about.blade.php ENDPATH**/ ?>