

<?php $__env->startSection('title', 'Posts'); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin._alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="d-flex">
  <h1 class="h3 mb-4 text-gray-800">Posts</h1>
  <div class="ml-auto">
    <a href="<?php echo e(route('create_blogs_path')); ?>" class="btn btn-sm btn-outline-success">Create new</a>
  </div>
  
</div>

<table class="table">
  <thead>
    <tr>
      <th>Image</th>
      <th>ID</th>
      <th>UserId</th>
      <th>Title</th>
      <th>Content</th>
      <th>Created At</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><img height="60" src="<?php echo e($blog->image); ?>"></td>
      <td><?php echo e($blog->id); ?></td>
      <td><?php echo e($blog->user_id); ?></td>
      <td><?php echo e($blog->title); ?></td>
      <td><?php echo $blog->content; ?></td>
      <td><?php echo e($blog->created_at); ?></td>
      <td>
        <div class="d-flex">
          <a class="btn btn-outline-primary btn-sm mr-1" href="<?php echo e(route('edit_blogs_path', [$blog->id])); ?>">Edit</a>
          <form method="post" action="<?php echo e(route('delete_blogs_path', [$blog->id])); ?>">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-danger btn-sm delete">Delete</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php echo e($blogs->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PalLancer\Laravel\myblog\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>