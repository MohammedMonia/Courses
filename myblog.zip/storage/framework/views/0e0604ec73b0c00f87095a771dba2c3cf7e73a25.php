




<?php $__env->startSection('content'); ?>
<?php echo $__env->make('fronts._alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="main-wrapper">
	    <section class="cta-section theme-bg-light py-5">
		    <div class="container text-center">
			    <h2 class="heading">Welcome to my blog, I hope to you best time</h2>
			    <div class="intro">Subscribe and get my latest blog post in your inbox.</div>
			    <form action="<?php echo e(route('subscribe.store' )); ?>" method="POST" class="signup-form form-inline justify-content-center pt-3">
				<?php echo csrf_field(); ?>                                  
                    <div class="form-group">                  
                        <label class="sr-only" for="name">Your name</label>
                        <input type="text" id="semail" name="name" class="form-control mr-md-1 semail" placeholder="Enter your name" value="<?php echo e(old('name')); ?>">
						          
                        <label class="sr-only" for="email">Your email</label>
						<input type="email" id="semail" name="email" class="form-control mr-md-1 semail <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"" placeholder="Enter your email" value="<?php echo e(old('email')); ?>">
						                       
                		<button type="submit" class="btn btn-primary ml-auto " >Subscribe</button>
					</div>
					<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<p class="text-danger ml-auto mr-5 mr-5"><?php echo e($message); ?></p>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</form>
               
		    </div><!--//container-->
	    </section>
	    <section class="blog-list px-3 py-5 p-md-5">
		<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <div class="container">
			    <div class="item mb-5">
				    <div class="media">
					    <img class="mr-3 img-fluid post-thumb d-none d-md-flex" src="<?php echo e($blog->image); ?>" alt="image">
					    <div class="media-body">
						    <h3 class="title mb-1"><a href="<?php echo e(route('blog_path', [$blog->id])); ?>"><?php echo e($blog->title); ?></a></h3>
						    <div class="meta mb-1"><span class="date">Published <?php echo e($blog->created_at->diffForHumans()); ?></span></div>
						    <div class="intro"><?php echo $blog->content; ?></div>
						    <a class="more-link" href="<?php echo e(route('blog_path', [$blog->id])); ?>">Read more &rarr;</a>
					    </div><!--//media-body-->
				    </div><!--//media-->
				</div><!--//item-->
			</div>
			
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    
			    
			    <nav class="blog-nav nav nav-justified my-5">
					<?php echo e($blogs->links()); ?>	
				</nav>
				
		    </div>
        </section>
        
<?php $__env->stopSection(); ?>
	    

<script>
	function myFunction(){
		if (confirm(onclick)){
			alert('Welcome... Your subscribe is succesfully!');
		}
		
	}
        	
</script>

<?php echo $__env->make('fronts.appfront', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PalLancer\Laravel\myblog\resources\views/fronts/posts/index.blade.php ENDPATH**/ ?>