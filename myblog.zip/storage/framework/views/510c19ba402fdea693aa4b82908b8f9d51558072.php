


<?php $__env->startSection('content'); ?>

<h2 style="text-align:center">Our Team</h2>
<div class="row">
  <div class="col-md-6">
    <div class="card center">
    <h2>Jane Doe</h2>
      <img src="/w3images/team1.jpg" alt="Jane" style="width:100%">
      
     
      </div>
    </div>
  </div>
  <div class="about-section">
  <h1>About Us Page</h1>
  <p>Some text about who we are and what we do.</p>
  <p>Resize the browser window to see that this page is responsive by the way.</p>
</div>


 
</div>

</body>
<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('csss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php $__env->stopSection(); ?>

</body>
</html>

<?php echo $__env->make('layouts.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PalLancer\Laravel\myblog\resources\views/blogs/about.blade.php ENDPATH**/ ?>