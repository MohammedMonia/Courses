<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>Bootstrap 4 Blog Template For Developers</title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Blog Template">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    
    <link rel="shortcut icon" href="favicon.ico"> 
    
    <!-- FontAwesome JS-->
    <script defer src="https://use.fontawesome.com/releases/v5.7.1/js/all.js" integrity="sha384-eVEQC9zshBn0rFj4+TU78eNA19HMNigMviK/PU/FFjLXqa/GKPgX58rvt5Z8PLs7" crossorigin="anonymous"></script>
    
    <!-- Plugin CSS -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.14.2/styles/monokai-sublime.min.css">
    
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="/assets/css/theme-3.css">
    

</head> 

<body>
    
<header class="header text-center">	    
	    <h1 class="blog-name pt-lg-4 mb-0"><a href="#">Mohamed Blog</a></h1>
        
	    <nav class="navbar navbar-expand-lg navbar-dark" >
           
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
			</button>

			<div id="navigation" class="collapse navbar-collapse flex-column" >
				<div class="profile-section pt-3 pt-lg-0">
				    <img class="profile-image mb-3 rounded-circle mx-auto" src="/assets/images/me.png" alt="image" >			
					
					<div class="bio mb-3">My name is Mohamed Monia. I love coding very much, and I am a proficient developer in web programming.<br><a href="<?php echo e(route('about.index')); ?>">Find out more about me</a></div><!--//bio-->
					<ul class="social-list list-inline py-3 mx-auto">
			            <li class="list-inline-item"><a href="https://twitter.com/MohamedMonia3"><i class="fab fa-twitter fa-fw"></i></a></li>
			            <li class="list-inline-item"><a href="https://www.linkedin.com/in/mohamed-monia-b126ab154"><i class="fab fa-linkedin-in fa-fw"></i></a></li>
			            <li class="list-inline-item"><a href="https://github.com/MohammedMonia"><i class="fab fa-github-alt fa-fw"></i></a></li>
			            <li class="list-inline-item"><a href="https://www.facebook.com/mhamed.monia/"><i class="fab fa-facebook fa-fw"></i></a></li>
			            <li class="list-inline-item"><a href="https://www.instagram.com/mhamed_monia"><i class="fab fa-instagram fa-fw"></i></a></li>
			        </ul><!--//social-list-->
			        <hr> 
				</div><!--//profile-section-->
				
				<ul class="navbar-nav flex-column text-left">
                <li class="nav-item active">
					    <a class="nav-link" href="<?php echo e(route('blogs_path_index1')); ?>"><i class="fas fa-home fa-fw mr-2"></i>Blog Home <span class="sr-only">(current)</span></a>
					</li>
					<li class="nav-item">
					    <a class="nav-link" href="#"><i class="fas fa-bookmark fa-fw mr-2"></i>Blog Post</a>
					</li>
					<li class="nav-item">
					    <a class="nav-link" href="<?php echo e(route('about.index')); ?>"><i class="fas fa-user fa-fw mr-2"></i>About Me</a>
				</ul>
				
				
			</div>
		</nav>
    </header>
    
    <div class="main-wrapper">
	    
	    <article class="blog-post px-3 py-5 p-md-5">
		    <div class="container">
			    <header class="blog-post-header">
                    
				    <h2 class="title mb-2"><?php echo e($blog->title); ?></h2>
				    <div class="meta mb-3"><span class="date">Published <?php echo e($blog->created_at->diffForHumans()); ?></span></div>
			    </header>
			    
			    <div class="blog-post-body">
				    <figure class="blog-banner">
				        <a href="https://made4dev.com"><img class="img-fluid" src="<?php echo e($blog->image); ?>" alt="image"></a>
				    </figure>
                    <p><?php echo $blog->content_description; ?></p>
                    
				    <form  action="<?php echo e(route('comments.store' )); ?>" method="POST" id="commentForm">
                    <?php echo csrf_field(); ?>
                    <label for="comment_body">Enter your comment</label>
                    <div class="d-flex">
                    <input value="<?php echo e($blog->id); ?>" style="display:none;" type="text" name="blog_id" class="form-control">
                    <input type="text" name="comment_body" class="form-control <?php $__errorArgs = ['comment_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="write a comment ...">
                    <?php $__errorArgs = ['comment_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <p></p>

                    <button type="submit" class="btn btn-outline-primary">Comment</button>
                    </div>
                    
                    </form>
                    
                    <h5 class="mt-2 mb-2">Comments :</h5>
                    <div class="cc">
                        <?php $__currentLoopData = $blog->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="meta mb-3"> 
                            <p style="color: black; background-color: #fffedc;"><?php echo e($comment->comment_body); ?></p>
                            <span class="date">Published <?php echo e($comment->created_at->diffForHumans()); ?></span>
                        </div>     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>
				    	
					<h5 class="mt-5">Embed A Tweet:</h5>
					
					<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">1969:<br>-what&#39;re you doing with that 2KB of RAM?<br>-sending people to the moon<br><br>2017:<br>-what&#39;re you doing with that 1.5GB of RAM?<br>-running Slack</p>&mdash; I Am Devloper (@iamdevloper) <a href="https://twitter.com/iamdevloper/status/926458505355235328?ref_src=twsrc%5Etfw">November 3, 2017</a></blockquote>
					<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>


				    
				    <h3 class="mt-5 mb-3"><?php echo e($blog->video_title); ?></h3>
				    <p><?php echo $blog->video_content; ?></p>

				    <div class="embed-responsive embed-responsive-16by9">
					   <iframe width="560" height="315" src="https://www.youtube.com/embed/hnCmSXCZEpU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>					
					</div>
				   
			    </div>
				    
			 
			
	    
	    
	    
	    <footer class="footer text-center py-2 theme-bg-dark">
		   
	        <!--/* This template is released under the Creative Commons Attribution 3.0 License. Please keep the attribution link below when using for your own project. Thank you for your support. :) If you'd like to use the template without the attribution, you can buy the commercial license via our website: themes.3rdwavemedia.com */-->
                <small class="copyright">Designed with <i class="fas fa-heart" style="color: #fb866a;"></i> by <a href="http://themes.3rdwavemedia.com" target="_blank">Xiaoying Riley</a> for developers</small>
		   
	    </footer>
    
    </div><!--//main-wrapper-->
    

    <!-- *****CONFIGURE STYLE (REMOVE ON YOUR PRODUCTION SITE)****** -->  
    <div id="config-panel" class="config-panel d-none d-lg-block">
        <div class="panel-inner">
            <a id="config-trigger" class="config-trigger config-panel-hide text-center" href="#"><i class="fas fa-cog fa-spin mx-auto" data-fa-transform="down-6" ></i></a>
            <h5 class="panel-title">Choose Colour</h5>
            <ul id="color-options" class="list-inline mb-0">
                <li class="theme-1 active list-inline-item"><a data-style="/assets/css/theme-1.css" href="#"></a></li>
                <li class="theme-2  list-inline-item"><a data-style="/assets/css/theme-2.css" href="#"></a></li>
                <li class="theme-3  list-inline-item"><a data-style="/assets/css/theme-3.css" href="#"></a></li>
                <li class="theme-4  list-inline-item"><a data-style="/assets/css/theme-4.css" href="#"></a></li>
                <li class="theme-5  list-inline-item"><a data-style="/assets/css/theme-5.css" href="#"></a></li>
                <li class="theme-6  list-inline-item"><a data-style="/assets/css/theme-6.css" href="#"></a></li>
                <li class="theme-7  list-inline-item"><a data-style="/assets/css/theme-7.css" href="#"></a></li>
                <li class="theme-8  list-inline-item"><a data-style="/assets/css/theme-8.css" href="#"></a></li>
            </ul>
            <a id="config-close" class="close" href="#"><i class="fa fa-times-circle"></i></a>
        </div><!--//panel-inner-->
    </div><!--//configure-panel-->

    
       
    <!-- Javascript -->          
    <script src="/assets/plugins/jquery-3.3.1.min.js"></script>
    <script src="/assets/plugins/popper.min.js"></script> 
    <script src="/assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
    
    <!-- Page Specific JS -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.14.2/highlight.min.js"></script>

    <!-- Custom JS -->
    <script src="/assets/js/blog.js"></script>
    
    <!-- Style Switcher (REMOVE ON YOUR PRODUCTION SITE) -->
    <script src="/assets/js/demo/style-switcher.js"></script> 
    
    <script>

    $(document).ready(function(){

        $('#commentForm').submit(function(e){
            
            e.preventDefault();

            let data = $(this).serialize();

            $.ajax({
                url : "<?php echo e(route('comments.store' )); ?>",
                type: 'POST',
                data: data,
                success: function(res){
                    $('.cc').prepend('<p>'+res+'</p>');
                    
                    $('input[name=comment_body]').val('');
                }
            });

        })

    });

</script>
    

</body>
</html> 

<?php /**PATH G:\PalLancer\Laravel\myblog\resources\views/fronts/show.blade.php ENDPATH**/ ?>