


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
        <img src="<?php echo e(asset($blog->image)); ?>" alt="" class="card-img-top">
        <br>
        <br>
            <h3><span style="color:blue;"><?php echo e(Auth::user()->name); ?></span>|<?php echo e($blog->title); ?></h3>
            <hr>
            <p class="lead">
                <?php echo $blog->content; ?>


                <form action="<?php echo e(route('comments.store' )); ?>" method="POST" id="commentForm">
                    <?php echo csrf_field(); ?>
                    <label for="comment_body">comment</label>
                    <div class="d-flex">
                    <input value="<?php echo e($blog->id); ?>" style="display:none;" type="text" name="blog_id" class="form-control">
                    <input type="text" name="comment_body" class="form-control <?php $__errorArgs = ['comment_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="write a comment ...">
                    <?php $__errorArgs = ['comment_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <p></p>

                    <button type="submit" class="btn btn-outline-primary">Comment</button>
                    </div>
                    
                </form> 
                <div class="cc">
                <?php $__currentLoopData = $blog->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <p><?php echo e($comment->comment_body); ?></p> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>
                         
                
                         
            </p>
            <a class="btn btn-outline-secondary" href="<?php echo e(route('blogs_path')); ?>">Back</a>
            <a class="btn btn-outline-info" href="<?php echo e(route('edit_blogs_path', [$blog->id])); ?>">Edit</a>
            <form action="<?php echo e(route('delete_blogs_path', [$blog->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
            <button class="btn btn-outline-danger mt-1" type="submit">Delete</button>
            </form>
        </div>
       
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<script>

    $(document).ready(function(){

        $('#commentForm').submit(function(e){
            
            e.preventDefault();

            let data = $(this).serialize();

            $.ajax({
                url : "<?php echo e(route('comments.store' )); ?>",
                type: 'POST',
                data: data,
                success: function(res){
                    $('.cc').prepend('<p>'+res+'</p>');
                    $('input[name=comment_body]').text('');
                }
            });

        })

    });

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PalLancer\Laravel\myblog\resources\views/blogs/show.blade.php ENDPATH**/ ?>