

<?php $__env->startSection('title', 'Posts'); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin._alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="d-flex">
  <h1 class="h3 mb-4 text-gray-800">Posts</h1>
  <div class="ml-auto">
    <a href="<?php echo e(route('create_blogs_path')); ?>" class="btn btn-sm btn-outline-success">Create new</a>
  </div>
  
</div>

<table class="table">
  <thead>
    <tr>
      <th>Image</th>
      <th>ID</th>
      <th>About Me Title</th>
      <th>About Me Body</th>
      <th>About Blog Title</th>
      <th>About Blog Body</th>
      <th>Created At</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><img height="60" src="<?php echo e($about->image); ?>"></td>
      <td><?php echo e($about->id); ?></td>
      <td><?php echo e($about->about_title); ?></td>
      <td><?php echo $about->about_body; ?></td>
      <td><?php echo e($about->aboutBlog_title); ?></td>
      <td><?php echo $about->aboutBlog_body; ?></td>
      <td><?php echo e($about->created_at); ?></td>
      <td>
        <div class="d-flex">
          <a class="btn btn-outline-primary btn-sm mr-1" href="<?php echo e(route('about.edit', [$about->id])); ?>">Edit</a>
          <form method="post" action="<?php echo e(route('about.destroy', [$about->id])); ?>">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-danger btn-sm delete">Delete</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PalLancer\Laravel\myblog\resources\views/admin/about.blade.php ENDPATH**/ ?>