<!DOCTYPE html>
<html lang="" dir='ltr'>
<head>
<meta charset="utf-8">
<title>Blog</title>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php echo $__env->yieldContent('css'); ?>
<?php echo $__env->yieldContent('csss'); ?>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">AboMazen</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('blogs_path')); ?>"> Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('create_blogs_path')); ?>">Create Blog Post</a>
      </li>  
      <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('about.index')); ?>" tabindex="-1" aria-disabled="true">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('contact.index')); ?>" tabindex="-1" aria-disabled="true">Contact</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>

<div class="container">
<?php echo $__env->yieldContent('content'); ?>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<?php echo $__env->yieldContent('js'); ?>
</body>

</html><?php /**PATH G:\PalLancer\Laravel\myblog\resources\views/layouts/application.blade.php ENDPATH**/ ?>