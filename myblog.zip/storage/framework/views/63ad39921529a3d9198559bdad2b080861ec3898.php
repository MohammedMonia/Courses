<?php echo e($slot); ?>

<?php /**PATH G:\PalLancer\Laravel\myblog\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>