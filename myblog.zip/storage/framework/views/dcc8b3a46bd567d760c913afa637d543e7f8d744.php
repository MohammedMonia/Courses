

<?php $__env->startSection('title', 'Subscribe'); ?>


<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin._alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="d-flex">
    <h1 class="h3 mb-4 text-gray-800">Subscribes Page</h1>
    
    </div>

<table class="table">
  <thead>
    <tr>
      
      <th>ID</th>
      <th>Name</th>
      <th>Email</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $subscribes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscribe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      
      <td><?php echo e($subscribe->id); ?></td>
      <td><?php echo e($subscribe->name); ?></td>
      <td><?php echo e($subscribe->email); ?></td>
      <td>
        <div class="d-flex">
          <form method="post" action="<?php echo e(route('subscribe.destroy', [$subscribe->id])); ?>">
            <?php echo method_field('delete'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-danger btn-sm delete">Delete</button>
          </form>
        </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PalLancer\Laravel\myblog\resources\views/admin/subscribe/subscribe.blade.php ENDPATH**/ ?>