
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('blogs._alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>This is my blog</h1>
              


<div class="row mt-5">
<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="col-md-4 mb-3">
        <div class="card">


            <div class="card-header">
                <a href="<?php echo e(route('blog_path', [$blog->id])); ?>"> <?php echo e(Auth::user()->name); ?>|<?php echo e($blog->title); ?> </a>
            </div>
            <div class="card-body">
                <a href="<?php echo e(route('blog_path' , [$blog->id])); ?>">
                <img src="<?php echo e(asset($blog->image)); ?>" alt="" class="card-img-top">
                </a>
                <?php echo $blog->content; ?> 
               
                
                
                
                
                            
                <br>
                <br>
                <br>
                <p class="lead">
                    Posted
                    <?php echo e($blog->created_at->diffForHumans()); ?>

                </p>
                <a class="btn btn-outline-primary" href="<?php echo e(route('blog_path', [ $blog->id])); ?>">View Post</a>
                
            </div>

        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.application', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\PalLancer\Laravel\myblog\resources\views/blogs/index.blade.php ENDPATH**/ ?>